package com.example.uts_mobileprogramming_nadiawulandari

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Makanan(
    val name: String,
    val description: String,
    val photo: Int,
    val keterangan: String // Tambahkan ini
) : Parcelable

